---
name: video-style-picker
description: Use whenever the user uploads or points to a video and wants it edited ("edit this", "clean cut this", "make this better", "caption this", "cut this video"). Inspects the footage (content, length, orientation, speech, pacing), recommends the best editing style with a short reason, asks the user to choose, then completes the whole edit automatically and returns the finished file. Offers Clean Cut for talking-head footage plus HyperFrames-built styles.
---

# Video style picker

This skill is the user's own routing rule (not part of the Clean Cut ZIP). Clean Cut = the `clean-cut` skill from the ZIP. Every
other style below is built with the installed HyperFrames plugin: never say those came from the ZIP.

## 1. Inspect (no questions, no editing yet)
- `ffprobe`: duration, resolution, fps, rotation -> orientation (vertical / horizontal / square), audio present.
- Pacing: `ffmpeg -i <f> -af silencedetect=noise=-40dB:d=0.4 -f null -` -> silence share, longest pauses.
- Content: pull ~8 evenly spaced frames (`ffmpeg -vf fps=...`/contact sheet) and LOOK at them: one person facing camera? screen
  recording? b-roll/scenery? music performance? multiple shots?
- Speech: transcribe with `python ~/.claude/skills/clean-cut/scripts/stt.py`-based flow (`01_transcribe.py`; transcriber is set to
  `local`; ElevenLabs only if the user already set `ELEVENLABS_API_KEY` in their own environment - NEVER ask them to paste a key in chat).
  Note words-per-minute, speech share, fillers/false starts, language.
- Check tools first: `ffmpeg -version`, `node -v` (22+), `python -c "import numpy, soundfile"`, `npx hyperframes doctor`
  (Chrome headless shell OK; whisper/Kokoro/MusicGen/Docker are optional). Fix what is missing (tell the user in one line first).

## 2. Recommend, then ask (AskUserQuestion, recommendation first)
Give a 3-4 line findings summary and one sentence of why. Offer 2-4 options that fit the footage:

| Footage | Options |
|---|---|
| Single talking head, speech-heavy | **Clean Cut** (ZIP: tight cut + plain 2-4 word captions, 9:16) · Captions-only styled (`hyperframes:embedded-captions`, footage untouched) · Graphic overlays (`hyperframes:talking-head-recut`, titles/lower-thirds/callouts) |
| Talking head, very slow/long with many pauses | Clean Cut first; mention it shortens the video most |
| Multi-shot / b-roll / no speech | Montage/footage remix (`hyperframes:general-video`) · Music-synced cut (`hyperframes:music-to-video`) |
| Music-driven | `hyperframes:music-to-video` |
Clean Cut is only offered for talking-head footage, and it intentionally adds no hooks/graphics/music (those are not in the free ZIP).
Do not edit until the user picks.

## 3. Execute automatically after the choice
Ask follow-ups ONLY for truly missing essentials (e.g. a title). Then: prepare project -> cut -> captions/visuals -> render ->
check (snapshots at start/middle/end: font real, nothing off-screen, caption not over the mouth; verify the final file with ffprobe
and a spot-listen via transcript) -> deliver the file (SendUserFile for the phone copy, give the full path of the master).
- Clean Cut: follow `~/.claude/skills/clean-cut/SKILL.md` exactly.
- Other styles: invoke the matching `hyperframes:*` skill (start from `hyperframes:hyperframes`), render, check, deliver.
- Save outputs beside the source in "<Title> - Edit"; copies in the session's working folder if the user is in a cloud session.
- Report: raw vs final length, what was cut, any doubts. Never print or request secrets.
