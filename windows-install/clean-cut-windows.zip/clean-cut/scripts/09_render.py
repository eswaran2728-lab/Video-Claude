#!/usr/bin/env python3
"""Step 9 - lint, render and make a phone copy. Works on Windows, Mac and Linux.
   09_render.py <project_dir> "<out_dir>" "<Title>" <fps, e.g. 24000/1001 or 30>
Render at the SOURCE frame rate (the same --fps given to 02_cut.py)."""
import os, re, shutil, subprocess, sys
from fractions import Fraction
P, OUT, TITLE = sys.argv[1:4]; FPS = sys.argv[4] if len(sys.argv) > 4 else "30"
npx = shutil.which("npx") or "npx"; os.makedirs(OUT, exist_ok=True)
fps = f"{float(Fraction(FPS)):.4f}".rstrip("0").rstrip(".")
r = subprocess.run([npx, "-y", "hyperframes", "lint"], cwd=P, capture_output=True, text=True); print("\n".join((r.stdout + r.stderr).splitlines()[-5:]))
F = os.path.join(OUT, f"{TITLE} - Clean Cut 9x16.mp4")
r = subprocess.run([npx, "-y", "hyperframes", "render", "-o", F, "--fps", fps, "--quality", "looks"], cwd=P, capture_output=True, text=True, encoding="utf-8", errors="replace")
txt = re.sub(r"\x1b\[[0-9;]*m", "", r.stdout + r.stderr); print("\n".join([l for l in txt.splitlines() if re.search(r"rendered in|MB ·|rror", l)][-3:]))
if r.returncode or not os.path.exists(F): sys.exit("render failed:\n" + txt[-1500:])
D = float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", F]).decode().strip())
BR = int(min(2900, 23 * 8000 / D - 160)); PH = os.path.join(OUT, f"{TITLE} - Clean Cut (phone).mp4")
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", F, "-c:v", "libx264", "-preset", "slow", "-b:v", f"{BR}k", "-maxrate", f"{BR * 5 // 4}k",
                "-bufsize", "6000k", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", PH], check=True)
print("master:", F); print("phone: ", PH)
