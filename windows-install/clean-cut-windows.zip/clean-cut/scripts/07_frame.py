#!/usr/bin/env python3
"""Step 7 - frame the cut as a 9:16 vertical video (1080x1920, with the audio). Works on Windows, Mac and Linux.
   07_frame.py "<CUT.mp4>" "<out 9x16.mp4>" [w h x y]
Horizontal source: pass a 9:16 crop window in source pixels with the face centred (3840x2160 -> 1215 2160 <x> 0 ; 1920x1080 -> 608 1080 <x> 0).
Vertical source: pass nothing, it is only scaled to 1080x1920."""
import subprocess, sys
c, o, *crop = sys.argv[1:]
vf = ("crop=" + ":".join(crop) + ",") if len(crop) == 4 else ""
vf += "scale=1080:1920:flags=lanczos"
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", c, "-vf", vf, "-c:v", "libx264", "-crf", "16", "-preset", "medium",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "320k", "-movflags", "+faststart", o], check=True)
print(subprocess.check_output(["ffprobe", "-v", "error", "-select_streams", "v", "-show_entries", "stream=width,height", "-of", "csv=p=0", o]).decode().strip())
